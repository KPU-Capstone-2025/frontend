export default function NotFound() {
  return (
    <div style={{ padding: "40px", fontFamily: "Pretendard, system-ui" }}>
      <h2 style={{ margin: 0 }}>404</h2>
      <p style={{ marginTop: 8, color: "#666" }}>페이지를 찾을 수 없어요.</p>
    </div>
  );
}
