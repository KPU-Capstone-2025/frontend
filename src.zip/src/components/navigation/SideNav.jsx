import NavItem from "./NavItem.jsx";

export default function SideNav({ open, onClose }) {
  return (
    <>
      {/* mobile overlay */}
      {open ? <div className="navOverlay" onClick={onClose} /> : null}

      <aside className={`sideNav ${open ? "open" : ""}`}>
        <div className="brand">
          <div className="brand__logo">M</div>
          <div className="brand__txt">
            <div className="brand__title">Monittoring</div>
            <div className="brand__sub">AI Monitoring</div>
          </div>
        </div>

        <nav className="navGroup">
          <NavItem to="/dashboard" icon="📊" label="대시보드" />
          <NavItem to="/servers" icon="🖥️" label="서버 상태" badge="준비중" />
          <NavItem to="/logs" icon="🧾" label="로그 분석" badge="준비중" />
          <NavItem to="/alerts" icon="🔔" label="알림 설정" badge="준비중" />
        </nav>

        <div className="navFooter">
          <span>© KPU Capstone</span>
          <span style={{ color: "rgba(255,255,255,0.7)" }}>v0.1</span>
        </div>
      </aside>
    </>
  );
}
